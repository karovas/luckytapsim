# The script of the game goes in this file.






init python:
    def lowbeep(event, interact=True, **kwargs):
        if not interact:
            return
        

        if event == "show_done":

            sounds = [
                "audio/lowbeep1.ogg",
                "audio/lowbeep3.ogg"
            ]
            renpy.sound.play(renpy.random.choice(sounds), channel="beep", loop=True)
        elif event == "slow_done" or event == "end":
            renpy.sound.stop(fadeout=1, channel="beep")



init python:
    renpy.music.register_channel("beep", mixer="voice")






init python:
    def medbeep(event, interact=True, **kwargs):
        if not interact:
            return
        

        if event == "show_done":

            sounds = [
                "audio/medbeep1.ogg",
                "audio/medbeep3.ogg"
            ]
            renpy.sound.play(renpy.random.choice(sounds), channel="beep", loop=True)
        elif event == "slow_done" or event == "end":
            renpy.sound.stop(fadeout=1, channel="beep")



init python:
    renpy.music.register_channel("beep", mixer="voice")








init python:
    def highbeep(event, interact=True, **kwargs):
        if not interact:
            return
        

        if event == "show_done":

            sounds = [
                "audio/highbeep1.ogg",
                "audio/highbeep3.ogg"
            ]
            renpy.sound.play(renpy.random.choice(sounds), channel="beep", loop=True)
        elif event == "slow_done" or event == "end":
            renpy.sound.stop(fadeout=1, channel="beep")



init python:
    renpy.music.register_channel("beep", mixer="voice")







# Declare characters used by this game. The color argument colorizes the
# name of the character.

define M = Character("ME", color="#ffffff")
define SP = Character("MISS SAMPLIN",  color="#FFFFFF", callback=lowbeep)
define EB = Character("Mr.Eedbeedmeed", color="#fff", callback=medbeep)
define JD = Character("Jidion", color="#fff", callback=lowbeep)
# The game starts here

default relationship_available = False
default relationship_status = "None"
default money = 1
default lucky_bucks = 0
default character_name = "Me"
default character_pfp = "images/me.png"

label start:

    show screen simple_hud    


    play music "opening_bgm.ogg" volume 0.2 fadein 3.0 

    scene bg bedroomday:
        xysize (1.0, 1.0)
        fit "cover"
    with fade


    "(You wake up bright and early for you first day of super senior Year)"

    "(School starts at 8:10 am, but its 8:00 am! Your LATE, better hurry and get to school!)"

    scene bg lrday:
        xysize (1.0, 1.0)
        fit "cover"
    with fade

    "(You get downstairs and see a note left for you.)"

    "..."

    "You take the piece of toast and run out the door with it still in your mouth."

    scene bg outsideday:
        xysize (1.0, 1.0)
        fit "cover"
    with fade

    M "Ive gotta rush to school! If I dont then I'll miss the entrance ceremony!!!"

    M "School starts at 8:10 AM! I'm so done for..."

    scene bg schooleday:
        xysize (1.0, 1.0)
        fit "cover"
    with fade

    "*bell rings*"

    M "OH NO THATS THE BELL!!!"

    scene bg hallwayday:
        xysize (1.0, 1.0)
        fit "cover"
    with fade

    M "I dont know where my class is.. This school is so much bigger than my junior high!!"

    M "..."

    show mssamplin normal:
        ysize 0.9
        fit "contain"
        xalign 0.5
        yalign 1.0
    with moveinbottom
    
    SP "hey.."

    SP "you lost there little first year puppy?.."
    
    
menu:
    "Uhhh.. no, I'm doing fine!...":
        jump no_fine

    "Yes!! could I get some help?":
        jump yes_help

        
label no_fine:
    SP "Hmmm, you know.. I'm truly a MasterFreshmenHelper, so you might want to reconsider."
    M "Oh... Sorry to burst your bubble, but I'm not a first year.."
    $ renpy.music.set_pause(True, channel="music")
    SP "..."
    "You stand there awkwardly while Miss Samplin stares at you with a blank look"
    SP "So you're telling me you're not a first year?"

menu:
    "I never said I was?..":
        jump samplin_leaves2
    "(stay quiet)":
        jump samplin_leaves2

label yes_help:
    SP "Well, you came to the right person. If you ask any of the other people about me, they'll tell you I'm the MasterFreshmenHelper."
    M "(Isnt this Miss Samplins first day here?.. I probably shouldn't mention it..)"
    M "Wow!.. You must be a great teacher then!"
    $ renpy.music.set_pause(True, channel="music")
    SP "Teacher?.."
    "You stare at her blankly, wondering if you said something wrong"
    $ renpy.music.set_pause(False, channel="music")
    SP "I'm a super senior silly!"
    "You have a suprised look on your face"
    SP "Wow.. You look so cute when you're suprised.."
    "Chills run down your spine"
    M "Haha.. yeah.."
    SP "Anyways, about that help.. Just take a left at the end of the hallway! Thats where the first year classes are."
    M "Oh.. I'm not a first yea-"
    SP "Well, I've got to get going anyways! See you around cutie pie.. *winks*"

    jump samplin_leaves1

label samplin_leaves1:
    hide mssamplin with moveoutbottom
    M "That was weird..."
    jump finding_classroom

label samplin_leaves2:
    hide mssamplin with moveoutbottom
    $ renpy.music.set_pause(False, channel="music")
    "You feel chills run down your spine"
    M "creepy..."
    jump finding_classroom

label finding_classroom:
    M "Well anyways, I still dont know where my classroom is!!"
    M "Gosh.. She was seriously no help."
    jump classroom

label classroom:
    play music "classroom_bgm.ogg" fadein 3.0 volume 0.2
    scene bg classroom:
        xysize (1.0, 1.0)
        fit "cover"
    with fade
    "You walk in and everyones staring at you"
    EB "I smell something smelly..."
    EB "Perhaps.. Did someone let a poot loose?.."
    EB "No need to be ashamed."

    JD "It just came out-"

    "Mr. Eedbeedmeed makes eye contact with you."

    #add eedbeedmeed popup here

    EB "WHO. are. you."
    EB "I do not remember asking for ANYONE to come to MY. CLASSROOM."

    "You stand there scared, while everyone in the classroom is looking at you."

    EB "Are you just going to stand there?"

    menu:
        "I'm sorry sir.. I woke up late, I swear I didnt mean to!":
            jump classroom2
        "You're lookin kinda cute.. ;)":
            jump classroom2


label classroom2:

    EB "SHUT. (Mr.EedBeedMeed swats his hand.)"

    "You flinch and jump back, worried what he might do next."

    EB "No need to be afraid, I totally understand!"

    EB "Actually I didn't get a lot of sleep last night either, what a coincidence!"
    EB "Here, this might help you out!"
    "Mr. Eedbeedmeed hands you a {color=#F52795}5 hour energy!{/color}"
    M "..."
    EB "What are you waiting for silly! Come to your seat."
    "You slowly walk in and take a seat at your desk."

